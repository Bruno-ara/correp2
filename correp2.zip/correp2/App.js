import React, { useState } from "react";
import {
 View,
 Text,
 TextInput,
 Button,
 StyleSheet,
 ToastAndroid,
 Image,
} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";


const Stack = createNativeStackNavigator();


/* ============================================
  TELA 1 – LOGIN
============================================ */
function TelaLogin({ navigation }) {
 const [user, setUser] = useState("");
 const [pass, setPass] = useState("");


 const USER_VALIDO = "aluno";
 const PASS_VALIDO = "123";


 function fazerLogin() {
   if (user === USER_VALIDO && pass === PASS_VALIDO) {
     ToastAndroid.show("Login realizado com sucesso!", ToastAndroid.SHORT);


     navigation.navigate("Menu Corridas", { usuario: user });
   } else {
     ToastAndroid.show("Usuário ou senha incorretos!", ToastAndroid.SHORT);
   }
 }


 return (
   <View style={styles.containerLogin}>
     <Text style={styles.title}>CorreP2</Text>


     <TextInput
       placeholder="Usuário"
       style={styles.input}
       value={user}
       onChangeText={setUser}
     />


     <TextInput
       placeholder="Senha"
       style={styles.input}
       secureTextEntry
       value={pass}
       onChangeText={setPass}
     />


     <Button title="ENTRAR" onPress={fazerLogin} />
   </View>
 );
}


/* ============================================
  TELA 2 – MENU DE CORRIDAS
============================================ */
function MenuCorridas({ route, navigation }) {
 const { usuario } = route.params;


 return (
   <View style={styles.container}>
     <Text style={styles.title}>Corridas Disponiveis</Text>
     <Button
       style={{marginTop: 20, marginBottom:20 }}
       title="Corrida da Opala"
       onPress={() =>
         navigation.navigate("CorridaExemplo1", { usuario: usuario })
       }
     />

     <Button
     style={{marginTop: 20, marginBottom:20 }}
       title="Corrida da Serra"
       onPress={() =>
         navigation.navigate("CorridaExemplo2", { usuario: usuario })
       }
     />


     <Button
     style={{marginTop: 20, marginBottom:20 }}
       title="Suas corridas"
       onPress={() =>
         navigation.navigate("Minhas Corridas", { usuario: usuario })
       }
     />
     <Button
     style={{marginTop: 20, marginBottom:20, }}
       title="Historico"
       onPress={() =>
         navigation.navigate("Histórico", { usuario: usuario })
       }
     />
   
   </View>
 );
}


/* ============================================
  TELA 3 – MINHAS CORRIDAS
============================================ */
function MinhasCorridas({ route, navigation }) {
 const { usuario } = route.params;


 return (
   <View style={styles.container}>
     <Text style={styles.title}>Suas corridas</Text>
     <Text style={styles.text}>Nenhuma corrida registrada</Text>


     <View style={{ marginTop: 20 }}>
       <Button title="Voltar " onPress={() => navigation.goBack()} />
     </View>
   </View>
 );
}


//corrida exemplo 1 
function CorridaExemplo1({ route, navigation }) {
 const { usuario } = route.params;


 return (
   <View style={styles.container}>
   <Image
       source={require("./portal.jpeg")}
       style={styles.imagem}
     />
     <Text style={styles.title}>Corrida da Opala</Text>
     <Text style={styles.subtitle}>Informações</Text>
     <Text style={styles.text}>5 Km</Text>

     <View style={{ marginTop: 20 }}>
       <Button title="Inscrever-se"/>
     </View>


     <View style={{ marginTop: 20 }}>
       <Button title="Voltar " onPress={() => navigation.goBack()} />
     </View>
   </View>
 );
}


//corrida exemplo 2
function CorridaExemplo2({ route, navigation }) {
 const { usuario } = route.params;


 return (
   <View style={styles.container}>
   <Image
       source={require("./serra.jpeg")}
       style={styles.imagem}
     />
     <Text style={styles.title}>Corrida da Serra</Text>
     <Text style={styles.subtitle}>Informações</Text>
     <Text style={styles.text}>3 Km</Text>
     <View style={{ marginTop: 20 }}>
       <Button title="Inscrever-se"/>
     </View>


     <View style={{ marginTop: 20 }}>
       <Button title="Voltar" onPress={() => navigation.goBack()} />
     </View>
   
   </View>
 );
}


//tela hisotrico
function Historico({ route, navigation }) {
 const { usuario } = route.params;


 return (
   <View style={styles.containerNormal}>
     <Text style={styles.title}>Historico</Text>
     <Text style={styles.text}>Ainda nada</Text>


     <View style={{ marginTop: 20 }}>
       <Button title="Voltar" onPress={() => navigation.goBack()} />
     </View>
   
   </View>
 );
}

































//roda o codigo
export default function App() {
 return (
   <NavigationContainer>
     <Stack.Navigator>
       <Stack.Screen name="Login" component={TelaLogin} />
       <Stack.Screen name="Menu Corridas" component={MenuCorridas} />
       <Stack.Screen name="CorridaExemplo1" component={CorridaExemplo1} />
       <Stack.Screen name="CorridaExemplo2" component={CorridaExemplo2} />
       <Stack.Screen name="Minhas Corridas" component={MinhasCorridas} />
       <Stack.Screen name="Histórico" component={Historico} />
     </Stack.Navigator>
   </NavigationContainer>
 );
}


//estilo
const styles = StyleSheet.create({
  containerLogin: {
   flex: 1,
   justifyContent: "center",
   alignItems: "center",
   padding: 25,
   marginBottom: 30,
 },
 container: {
   flex: 1,
   justifyContent: "center",
   alignItems: "center",
   padding: 10,
 },
  containerNormal: {
    padding: 10,
  },
 title: {
   fontSize: 50,
   fontWeight: "bold",
   textAlign: "center",
   marginBottom: 20,
 },
 subtitle: {
   fontSize: 16,
   fontWeight: "bold",
   textAlign: "center",

 },
  imagem: {
    width: 450,
    height: 300,
 },
 input: {
   backgroundColor: "#fff",
   padding: 12,
   width: "90%",
   borderRadius: 8,
   borderWidth: 1,
   borderColor: "#ccc",
   marginBottom: 15,
   fontSize: 16,
 },
 logo: {
   width: 150,
   height: 150,
   marginBottom: 20,
   resizeMode: "contain",
 },
 text: {
   fontSize: 18,
   marginVertical: 4,
   textAlign: "center",
 },
});











